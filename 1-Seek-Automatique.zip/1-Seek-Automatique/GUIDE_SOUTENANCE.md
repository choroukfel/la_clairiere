# Guide de soutenance — La Clairière

## 1. Démonstration recommandée (8 à 10 minutes)

Avant de commencer : ouvrir le jeu (de préférence avec `npx serve .` si tu veux le micro), cocher *Ambiance sonore*.

1. **Le jeu (1 min)** : choisir *Montagne de Glace* (veilleur : lynx). Guider la luciole, sauver deux esprits. Montrer le **cortège** qui suit la luciole en file : *leader following* et *arrive avec décalage* (exemple 3-Arrival_correction).
2. **Debug (2 min)** : Réglages → *Visualiser les vecteurs de pilotage*. Montrer :
   - autour d'un esprit, le cercle de **déclenchement** (blanc, rouge s'il est franchi) et la **distance de sécurité** (vert) — ils sont distincts ;
   - la **barre d'endurance** sous un esprit en fuite, puis « zZ » quand il est épuisé : il redevient vulnérable et ne refuit qu'une fois en sécurité ;
   - les **barres du réseau de neurones** au-dessus d'un esprit en fuite (évitement, séparation, vers la luciole, vers le refuge, se cacher) ;
   - le lynx qui vise le **point d'interception** (poursuite parfaite, exemple 2-PursueEvade_correction).
3. **Ligne de vue et cachettes (1 min)** : un esprit derrière un rocher n'est plus vu ; le veilleur part **enquêter** à sa dernière position connue (« ? »).
4. **Appel (1 min)** : touche **C** (ou clap au micro). Les esprits qui entendent accourent… et les veilleurs aussi : c'est de la **perception auditive**, avec un rayon d'audition qui grandit avec le volume.
5. **Algorithme génétique en direct (2 min)** :
   - *Feux follets migrateurs* (exemple 10) : montrer le statut « génération N · X / 18 au nid » dans le panneau de mission. Chaque feu follet suit son ADN de trajectoire (une force par image) ; après chaque vol de 10 s, les meilleurs sont sélectionnés, croisés et mutés. Au bout de quelques minutes, ils contournent les obstacles et arrivent au nid.
   - *Capteurs à rayons* (exemples 9 / 9b) : en debug, les trois rayons d'un esprit en fuite (vert libre, rouge sur un obstacle ou un veilleur) entrent dans son réseau de neurones, qui choisit le dosage des comportements.
6. **Code (2 min)** : montrer `fleeTarget.js` (`think` / `steer`), `sceneController.js` (une seule locomotion par image), `vehicle.js` identique au cours, puis `node --test tests/*.test.mjs` (97 tests).

## 2. Notions à expliquer

- **Vehicle** : position, vitesse, accélération, `maxSpeed`, `maxForce`. `applyForce()` accumule, `update()` intègre. Fichier du cours, non modifié.
- **Steering** : force = vitesse désirée − vitesse actuelle, limitée par `maxForce`. Tous les comportements suivent cette loi, y compris le freinage (vitesse désirée nulle) et la traînée des confettis.
- **Trois niveaux de Reynolds** : sélection de l'action (`think`), steering (`steer`), locomotion (`update`, une fois par image).
- **Seek / Flee / Arrive / Pursue / Evade / Wander / Boids / Path following / Obstacle avoidance** : voir le tableau du README, qui indique où chaque exemple du cours apparaît dans le jeu.
- **Hide** : point caché derrière un obstacle, à l'opposé de la menace, rejoint par *arrive*.
- **Poursuite parfaite** : on résout \|D + V t\| = s t pour viser l'endroit où la cible sera.
- **Fuite réglementée** : rayon de déclenchement ≠ distance de sécurité ; endurance ; épuisement ; réarmement seulement en sécurité.
- **Évolution** : ADN, fitness, sélection, croisement, mutation. **Neuroévolution** : les poids d'un réseau sont des gènes ; pas de rétropropagation.

## 3. Résultats mesurés (à annoncer honnêtement)

- Esprits neuronaux : **71,0 %** de sauvetage contre **53,9 %** pour les esprits classiques, sur 6 cartes inédites (+17,1 points, 6 cartes sur 6).
- Ce gain vient des comportements en plus (se cacher, rejoindre la luciole ou un refuge) et de ce que l'évolution a appris (bons poids moyens et gènes). Le réseau figé à ses poids moyens fait aussi bien (73,6 %) : la réaction au cas par cas n'apporte pas de gain mesurable.
- L'entraînement des esprits est sensible au hasard : sur six candidats, un seul battait des réseaux aléatoires en validation ; c'est lui qui est installé, puis mesuré sur d'autres cartes.
- Feux follets : premières arrivées entre la génération 6 et 18 selon la carte, puis 7 à 14 sur 18 au nid vers la génération 40-50.

## 4. Limites

- Les mesures du réseau viennent d'une arène simplifiée (luciole scriptée) : avec un vrai joueur, elles peuvent changer.
- Les comportements sont heuristiques ; il n'existe pas une combinaison optimale universelle.
- L'évolution est stochastique : elle ne progresse pas à chaque génération.
- Les tests automatisés ne remplacent pas un essai sur l'ordinateur de la démonstration.
