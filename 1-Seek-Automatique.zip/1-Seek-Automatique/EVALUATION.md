# Évaluation des esprits neuronaux (Clairière)

Généré par `node tools/evaluate-spirits.mjs --maps=6 --minutes=5 --first-seed=1001`.

6 cartes inédites (graines 1001 à 1006), 5 min simulées chacune, dans l'arène réduite de
`tests/spiritHarness.mjs` : 3 veilleurs, 8 esprits, une luciole **scriptée** qui va secourir l'esprit le plus menacé,
6 obstacles, un refuge toutes les 20 s. Aucun apprentissage pendant la mesure. Avec un vrai joueur, les chiffres changent.

| Esprits | Taux de sauvetage (moyenne ± écart-type) | Min – max par carte | Sauvés | Attrapés |
|---|---|---|---|---|
| réseaux entraînés | 71.0 % ± 5.9 | 60.6 – 78.3 % | 1422 | 582 |
| entraînés figés (poids constants) | 73.6 % ± 2.3 | 70.6 – 77.1 % | 1423 | 509 |
| mêmes gènes, réseaux aléatoires | 68.1 % ± 1.7 | 66.3 – 71.1 % | 1327 | 623 |
| esprits classiques (sans réseau) | 53.9 % ± 1.6 | 51.0 – 55.4 % | 849 | 726 |

Écarts appariés (une même carte, deux conditions). Un écart inférieur à environ deux erreurs types n'est pas
significatif : il peut venir du hasard des parties.

| Comparaison (même carte) | Écart moyen ± erreur type | Cartes où le premier gagne |
|---|---|---|
| réseaux entraînés − entraînés figés (poids constants) | -2.6 pt ± 2.3 | 1 / 6 |
| réseaux entraînés − mêmes gènes, réseaux aléatoires | +2.8 pt ± 2.4 | 5 / 6 |
| entraînés figés (poids constants) − mêmes gènes, réseaux aléatoires | +5.5 pt ± 0.5 | 6 / 6 |
| réseaux entraînés − esprits classiques (sans réseau) | +17.1 pt ± 2.2 | 6 / 6 |

Détail par carte :

| Carte | réseaux entraînés | entraînés figés (poids constants) | mêmes gènes, réseaux aléatoires | esprits classiques (sans réseau) |
|---|---|---|---|---|
| 1001 | 72.3 % | 73.5 % | 68.1 % | 55.4 % |
| 1002 | 71.2 % | 77.1 % | 71.1 % | 54.7 % |
| 1003 | 78.3 % | 71.6 % | 67.4 % | 54.5 % |
| 1004 | 69.8 % | 74.4 % | 69.1 % | 51.0 % |
| 1005 | 60.6 % | 70.6 % | 66.3 % | 52.9 % |
| 1006 | 73.7 % | 74.5 % | 67.0 % | 54.8 % |

Poids moyens choisis en fuite par les réseaux entraînés (condition « figés ») : evade 3.22, separate 2.20, toPlayer 2.82, toRefuge 2.99, toHide 2.81.
