# Analyse technique — La Clairière (version enrichie)

## Objectif
La Clairière est un jeu pédagogique en p5.js qui réunit les comportements de pilotage (steering behaviors), les comportements collectifs (Boids), l'évitement d'obstacles, le suivi de trajectoire et une introduction aux algorithmes génétiques.

## Architecture
- `vehicle.js` : classe de base `Vehicle` du cours (`1-Seek`), non modifiée.
- `steeringBehaviors.js` : `seek`, `arrive`, `pursue`, `evade`, `flee`, `wander`, `separate`, `align`, `cohesion`, `followPath`, `avoidObstacle`, `projectOnSegment` et `combine`.
- `evolution.js` : modèles d'évolution (ADN des comportements, sélection et mutation, ADN de trajectoire des feux follets migrateurs, population génétique, réseau neuronal). Les entités correspondantes ont chacune leur fichier : `geneticRocket.js`, `migratingWisp.js`, `wispNest.js` ; `sensorRay.js` (capteurs à rayons des esprits) est une perception.
- `fleeTarget.js` et `seekVehicle.js` : agents du jeu héritant de `Vehicle`. `FleeTarget` sépare `think()` (perception, mode), `steer()` (forces) et la locomotion héritée, appelée une fois par image par `sketch.js`.
- `neuralSpirit.js` (`NeuralSpirit extends FleeTarget`), `neuralSteeringDNA.js` et `spiritBrainPool.js` : esprits à réseau de neurones, leur ADN et la mémoire des meilleurs cerveaux.
- `environment.js` (lieux et scène), `environmentElement.js`, `obstacle.js`, `sanctuary.js`, `powerUp.js`, `hideSpot.js`, `sceneParticle.js`, `sceneRing.js`, `sceneLabel.js` : éléments du monde et effets, un fichier par entité, tous basés sur `Vehicle`.
- `sketch.js` : orchestration de la partie principale.
- `mission.js` : règles de progression et objectifs.

## Méthodes de pilotage
`seek` produit une force qui dirige l'agent vers une cible. `arrive` réduit la vitesse souhaitée à proximité. `pursue` et `evade` prédisent une position future à partir de la vitesse de la cible. `wander` crée une errance progressive. `separate`, `align` et `cohesion` forment les trois forces classiques des Boids. `projectOnSegment` réalise une projection scalaire bornée sur un segment, utilisée par `followPath`. `avoidObstacle` projette la trajectoire et génère une force de contournement. `combine` additionne les forces pondérées et limite la résultante.

## Évolution génétique
Chaque esprit sauvage possède un `SteeringDNA` (poids de fuite, séparation, cohésion, rayon de perception et vitesse de fuite). Lorsqu'elle est activée dans Réglages, l'évolution périodique sélectionne les individus ayant obtenu les meilleurs scores de survie/menace, croise leurs gènes et mute les descendants. La duplication existante transmet aussi les gènes du parent avec une mutation.

La classe `NeuralNetwork` d'`evolution.js` est maintenant utilisée en jeu : les esprits sauvages (`NeuralSpirit`) s'en servent pour choisir, pendant une fuite, le poids des comportements evade, séparation, rejoindre la luciole et rejoindre un refuge. Leurs poids évoluent par neuroévolution dans `SpiritBrainPool`, amorcé par `spiritBrainPretrained.js` (voir le README).

## Robustesse
- Les positions de secours recherchent une zone libre et vérifient les collisions avec les agents, les obstacles et les autres cibles.
- Après un changement d'environnement, les entités placées dans les obstacles sont repositionnées.
- La sortie du pointeur ne déclenche plus une errance soudaine : la dernière position connue est conservée.
- Le déplacement suit la locomotion du cours (une intégration par image). Les arrêts se font par freinage (force), jamais en remettant la vitesse à zéro ; les seules écritures directes de position sont des règles de scène explicites (réapparition, redimensionnement, bouclage du décor).
- Le mode Debug affiche les rayons de perception, les vecteurs de vitesse et les marges d'obstacles.

## Limites connues
- Les paramètres restent heuristiques : ils doivent être équilibrés empiriquement.
- Les simulations génétiques sont stochastiques et peuvent demander plusieurs générations avant de produire une trajectoire performante.
- Les voitures génétiques sont une démonstration de capteurs et de réseaux neuronaux simples ; elles ne constituent pas un système de conduite robuste.
- Les tests Node.js couvrent les méthodes et scénarios unitaires. Une vérification manuelle du navigateur reste nécessaire pour le rendu, les commandes et l'équilibrage.

## Exécution et tests
Ouvrir `index.html` dans un navigateur récent, ou utiliser un serveur local. Pour lancer les tests automatisés :

```bash
node --test tests/*.test.mjs
```
